from config.db import criar_conexao


def cadastrar_compra(preco_compra, id_cliente, id_produto, id_usuario):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'INSERT INTO farmacia.compras (preco_compra, id_cliente, id_produto, id_usuario) VALUES (%s, %s, %s, %s)'
            cursor.execute(sql, [preco_compra, id_cliente, id_produto, id_usuario])
            conn.commit()
    except Exception as e:
        print(f"Erro ao cadastrar compra: {e}")
    finally:
        if conn:
            conn.close()


def listar_compras(id_usuario):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'SELECT * FROM farmacia.compras WHERE id_usuario = %s'
            cursor.execute(sql, [id_usuario])
            compras = cursor.fetchall()
        return compras
    except Exception as e:
        print(f"Erro ao listar compras: {e}")
        return []
    finally:
        if conn:
            conn.close()
