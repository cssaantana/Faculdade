from config.db import criar_conexao


def adicionar_cliente(nome_cliente, endereco, cpf, telefone):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'INSERT INTO farmacia.clientes (nome_cliente, endereco, cpf, telefone) VALUES (%s, %s, %s, %s)'
            cursor.execute(sql, [nome_cliente, endereco, cpf, telefone])
            conn.commit()
    except Exception as e:
        print(f"Erro ao adicionar cliente: {e}")
    finally:
        if conn:
            conn.close()


def listar_clientes():
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'SELECT * FROM farmacia.clientes'
            cursor.execute(sql)
            clientes = cursor.fetchall()
        return clientes
    except Exception as e:
        print(f"Erro ao listar clientes: {e}")
        return []
    finally:
        if conn:
            conn.close()


def remover_cliente(id_cliente):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'DELETE FROM farmacia.clientes WHERE id_cliente = %s'
            cursor.execute(sql, [id_cliente])
            conn.commit()
    except Exception as e:
        print(f"Erro ao remover cliente: {e}")
    finally:
        if conn:
            conn.close()


def atualizar_cliente(id_cliente, nome_cliente, endereco, telefone):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'UPDATE farmacia.clientes SET nome_cliente = %s, endereco = %s, telefone = %s WHERE id_cliente = %s'
            cursor.execute(sql, [nome_cliente, endereco, telefone, id_cliente])
            conn.commit()
    except Exception as e:
        print(f"Erro ao atualizar cliente: {e}")
    finally:
        if conn:
            conn.close()
