from servicos.cliente_servicos import adicionar_cliente, listar_clientes, remover_cliente, atualizar_cliente
from servicos.produto_servicos import adicionar_produto, listar_produtos, remover_produto, atualizar_produto
from servicos.compra_servicos import cadastrar_compra, listar_compras

def validar_entrada_numero(mensagem):
    while True:
        try:
            valor = int(input(mensagem))
            return valor
        except ValueError:
            print("Entrada inválida. Por favor, insira um número.")

def menu_clientes():
    while(True):
        print("""
        1 - Cadastrar cliente
        2 - Listar clientes
        3 - Deletar cliente
        4 - Atualizar cliente
        5 - Sair
        """)

        opc = input("Digite a opção desejada: ")

        if opc == "1":
            nome_cliente = input("Digite o nome do cliente: ")
            endereco = input("Digite o endereço do cliente: ")
            cpf = input("Digite o CPF do cliente: ")
            telefone = input("Digite o telefone do cliente: ")
            adicionar_cliente(nome_cliente, endereco, cpf, telefone)
            print("Cliente adicionado com sucesso!")
        elif opc == "2":
            clientes = listar_clientes()
            print(clientes)
        elif opc == "3":
            id_cliente = validar_entrada_numero("Digite o ID do cliente a ser removido: ")
            remover_cliente(id_cliente)
            print("Cliente removido com sucesso!")
        elif opc == "4":
            id_cliente = validar_entrada_numero("Digite o ID do cliente a ser atualizado: ")
            nome_cliente = input("Digite o nome do cliente: ")
            endereco = input("Digite o endereço do cliente: ")
            telefone = input("Digite o telefone do cliente: ")
            atualizar_cliente(id_cliente, nome_cliente, endereco, telefone)
            print("Cliente atualizado com sucesso!")
        elif opc == "5":
            break

def menu_produtos():
    while(True):
        print("""
        1 - Cadastrar produto
        2 - Listar produtos
        3 - Deletar produto
        4 - Atualizar produto
        5 - Sair
        """)

        opc = input("Digite a opção desejada: ")

        if opc == "1":
            nome_produto = input("Digite o nome do produto: ")
            quantidade_produto = validar_entrada_numero("Digite a quantidade do produto: ")
            preco_produto = float(input("Digite o preço do produto: "))
            adicionar_produto(nome_produto, quantidade_produto, preco_produto)
            print("Produto adicionado com sucesso!")
        elif opc == "2":
            produtos = listar_produtos()
            print(produtos)
        elif opc == "3":
            id_produto = validar_entrada_numero("Digite o ID do produto a ser removido: ")
            remover_produto(id_produto)
            print("Produto removido com sucesso!")
        elif opc == "4":
            id_produto = validar_entrada_numero("Digite o ID do produto a ser atualizado: ")
            nome_produto = input("Digite o nome do produto: ")
            quantidade_produto = validar_entrada_numero("Digite a quantidade do produto: ")
            preco_produto = float(input("Digite o preço do produto: "))
            atualizar_produto(id_produto, nome_produto, quantidade_produto, preco_produto)
            print("Produto atualizado com sucesso!")
        elif opc == "5":
            break

def menu_compras(usuario):
    while(True):
        print("""
        1 - Cadastrar compra
        2 - Listar compras
        3 - Sair
        """)

        opc = input("Digite a opção desejada: ")

        if opc == "1":
            preco_compra = float(input("Digite o preço da compra: "))
            id_cliente = validar_entrada_numero("Digite o ID do cliente: ")
            id_produto = validar_entrada_numero("Digite o ID do produto: ")
            cadastrar_compra(preco_compra, id_cliente, id_produto, usuario[0])
            print("Compra cadastrada com sucesso!")
        elif opc == "2":
            compras = listar_compras(usuario[0])
            print(compras)
        elif opc == "3":
            break

def admin_tela(usuario):
    while(True):
        print(f"Bem-vindo, {usuario[1]}")
        print("""
        1 - Gerenciar clientes
        2 - Gerenciar produtos
        3 - Gerenciar compras
        4 - Sair
        """)

        menu = input("Digite a opção desejada: ")

        if menu == "1":
            menu_clientes()
        elif menu == "2":
            menu_produtos()
        elif menu == "3":
            menu_compras(usuario)
        elif menu == "4":
            break
