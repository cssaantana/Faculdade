def listar_compras_produtos_ordenados(id_usuario, nome_produto_busca):
    conn = criar_conexao() 
    cursor = conn.cursor() 
    sql = """
        SELECT compras.id_compra, compras.preco_compra, produtos.nome_produto
        FROM farmacia.compras
        INNER JOIN farmacia.produtos ON compras.id_produto = produtos.id_produto
        WHERE compras.id_usuario = %s
        AND produtos.nome_produto LIKE %s
        ORDER BY compras.preco_compra DESC
    """
    cursor.execute(sql, [id_usuario, '%' + nome_produto_busca + '%']) 
    resultados = cursor.fetchall()  
    return resultados 
