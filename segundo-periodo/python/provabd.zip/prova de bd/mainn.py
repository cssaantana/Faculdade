import getpass
from servicos.usuario_servicos import inserir_usuario, login
from telas.admin_tela import admin_tela

def cadastrar_usuario():
    email = input("Digite o email: ")
    password = getpass.getpass("Digite a senha: ")  # Senha oculta ao digitar
    inserir_usuario(email, password)
    print("Usuário cadastrado com sucesso!")

def realizar_login():
    email = input("Digite o email: ")
    password = getpass.getpass("Digite a senha: ")  # Senha oculta ao digitar
    usuario_autenticado = login(email, password)
    if usuario_autenticado:
        admin_tela(usuario_autenticado)
    else:
        print("Usuário ou senha inválidos!")

while(True):
    print("\n1 - Cadastrar Usuário\n2 - Login\n3 - Sair")
    opc = input("Digite a opção desejada: ")

    if opc == "1":
        cadastrar_usuario()
    elif opc == "2":
        realizar_login()
    elif opc == "3":
        print("Saindo...")
        break
    else:
        print("Opção inválida. Tente novamente.")
