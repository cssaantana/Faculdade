from config.db import criar_conexao


def adicionar_produto(nome_produto, quantidade_produto, preco_produto):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'INSERT INTO farmacia.produtos (nome_produto, quantidade_produto, preco_produto) VALUES (%s, %s, %s)'
            cursor.execute(sql, [nome_produto, quantidade_produto, preco_produto])
            conn.commit()
    except Exception as e:
        print(f"Erro ao adicionar produto: {e}")
    finally:
        if conn:
            conn.close()


def listar_produtos():
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'SELECT * FROM farmacia.produtos'
            cursor.execute(sql)
            produtos = cursor.fetchall()
        return produtos
    except Exception as e:
        print(f"Erro ao listar produtos: {e}")
        return []
    finally:
        if conn:
            conn.close()


def remover_produto(id_produto):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'DELETE FROM farmacia.produtos WHERE id_produto = %s'
            cursor.execute(sql, [id_produto])
            conn.commit()
    except Exception as e:
        print(f"Erro ao remover produto: {e}")
    finally:
        if conn:
            conn.close()


def atualizar_produto(id_produto, nome_produto, quantidade):
    try:
        conn = criar_conexao()
        with conn.cursor() as cursor:
            sql = 'UPDATE farmacia.produtos SET nome_produto = %s, quantidade_produto = %s WHERE id_produto = %s'
            cursor.execute(sql, [nome_produto, quantidade, id_produto])
            conn.commit()
    except Exception as e:
        print(f"Erro ao atualizar produto: {e}")
    finally:
        if conn:
            conn.close()
